import Link from "next/link";
export default function Home(){
 return <><nav className="nav"><div className="brand">Dil Ki Baat ❤️</div><div><Link href="/login">Login</Link> &nbsp; <Link className="btn" href="/register">Join Now</Link></div></nav>
 <main className="hero"><div className="container"><div className="card"><p>❤️ Aapke dil ki baat, ek khaas insaan tak.</p><h1>Real connections.<br/>Private conversations.</h1><p>Profiles dekhiye, interest bhejiye aur matched person ke saath secure private chat kijiye.</p><Link className="btn" href="/register">Create Your Profile</Link></div></div></main>
 <section className="container"><div className="grid"><div className="card"><h3>✓ Verified accounts</h3><p className="muted">Phone OTP verification flow included.</p></div><div className="card"><h3>🔒 Private chat</h3><p className="muted">Har connection ki separate 1-to-1 conversation.</p></div><div className="card"><h3>🛡️ Safety tools</h3><p className="muted">Block, report and moderation-ready database.</p></div></div></section></>;
}
