import {NextResponse} from "next/server"; import twilio from "twilio"; import {z} from "zod";
const schema=z.object({phone:z.string().min(8).max(20),code:z.string().length(6)});
export async function POST(req:Request){
 try{const {phone,code}=schema.parse(await req.json());const sid=process.env.TWILIO_ACCOUNT_SID,token=process.env.TWILIO_AUTH_TOKEN,service=process.env.TWILIO_VERIFY_SERVICE_SID;if(!sid||!token||!service) return NextResponse.json({error:"Twilio is not configured."},{status:500});
 const client=twilio(sid,token); const check=await client.verify.v2.services(service).verificationChecks.create({to:phone,code}); if(check.status!=="approved") return NextResponse.json({error:"Invalid or expired OTP."},{status:400}); return NextResponse.json({ok:true,verified:true});
 }catch(e:any){return NextResponse.json({error:e?.message||"OTP verification failed"},{status:400})}
}
