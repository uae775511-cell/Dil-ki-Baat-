import {NextResponse} from "next/server"; import twilio from "twilio"; import {z} from "zod";
const schema=z.object({phone:z.string().min(8).max(20)});
export async function POST(req:Request){
 try{const {phone}=schema.parse(await req.json());const sid=process.env.TWILIO_ACCOUNT_SID,token=process.env.TWILIO_AUTH_TOKEN,service=process.env.TWILIO_VERIFY_SERVICE_SID;if(!sid||!token||!service) return NextResponse.json({error:"Twilio is not configured. Add credentials to .env.local."},{status:500});
 const client=twilio(sid,token); await client.verify.v2.services(service).verifications.create({to:phone,channel:"sms"}); return NextResponse.json({ok:true});
 }catch(e:any){return NextResponse.json({error:e?.message||"Could not send OTP"},{status:400})}
}
